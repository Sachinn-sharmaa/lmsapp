import React from 'react';
import '../styles/HomePage.css'

const HomePage = () => {
  return (
    <div className="homepage-container">
      
      {/* Header */}
      <header className="header">
        <div className="logo">FindMyTution</div>
        <button className="login-button">Login</button>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <p className="tagline">Restricted by opportunities?</p>
        <h1 className="main-heading">
          Get the tech career <br /> you deserve. Faster.
        </h1>
        <p className="subheading">
          Structured coding courses that get you there faster with confidence.
        </p>
        <button className="explore-button">Explore offerings</button>
      </section>
    </div>
  );
};

export default HomePage;
